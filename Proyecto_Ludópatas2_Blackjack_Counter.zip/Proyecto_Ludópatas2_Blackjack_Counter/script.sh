#!/bin/bash
########################################################################
# Nombre de el script : Estádisticas de jugadas de BlacJack entre 3 amigos
# Descripción: Procesa el registro de 10 jugadas de blackjack entre 3 jugadores
#	       donde evalua cuantas rondas gano cada quien,
#	       cúanto dinero gano o perdió cada jugador y valores obtenidos en cada ronda
# Autores: Alonso Robles, Adán Alvarez y Alexander Roque
# Fecha: 11/10/2026
# Versión: 1.0
# Uso: ./script.sh rondas21.txt
#######################################################################
#---------------VARIABLES---------------
entrada="${1:-rondas21.txt}"
salida="salida.txt"

#------------Datos de jugador------------------
read -p "Nombre del jugador:" jugador

#-------jugador(rondas ganadas, perdidas, empates y dinero)--
# Partidas ganadas,perdidas y empatadas
ganadas=$(grep "$jugador" "$entrada" | grep -c "gano")
perdidas=$(grep "$jugador" "$entrada" | grep -c "perdio")
empate=$(grep "$jugador" "$entrada" | grep -c "empate")

#reporte
echo "-------------Rondas de blacjack---------------" > "$salida"
echo "" >> "$salida"
echo "---Rondas(todos los jugadores)-----" >> "$salida"
sed 's/ | /\t/g' "$entrada" >> "$salida"
echo "" >> "$salida"
echo "----Resultados de $jugador ----" >> "$salida"
echo "Rondas gandas   : $ganadas" >> "$salida"
echo "Rondas perdidas : $perdidas" >> "$salida"
echo "Empates	      : $empate" >> "$salida"
echo "" >> "$salida"
echo "------Dinero de $jugador en cada ronda-----" >> "$salida"
grep -e "^ronda" -e "$jugador" "$entrada" | sed 's/ | /\t/g' >> "$salida"

## se muestra todo en la pantalla
cat "$salida" 
